from .color_constants import color_dict


# copyright: https://www.webucator.com/blog/2015/03/python-color-constants-module/